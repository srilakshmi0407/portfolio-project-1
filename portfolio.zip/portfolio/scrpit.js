
  // Adding click functionality for capsules
document.querySelectorAll('#education .capsule').forEach((capsule) => {
    capsule.addEventListener('click', function() {
        const nameElement = this.querySelector('div:first-child'); // Get the first div which contains the name
        const detailsElement = this.querySelector('.details'); // Get the details element

        if (this.classList.contains('expand')) {
            this.classList.remove('expand'); // Collapse capsule
            nameElement.style.display = 'block'; // Show name again
            detailsElement.style.display = 'none'; // Hide details
        } else {
            // Collapse all other capsules
            document.querySelectorAll('#education .capsule').forEach(capsule => {
                capsule.classList.remove('expand');
                const otherNameElement = capsule.querySelector('div:first-child');
                const otherDetailsElement = capsule.querySelector('.details');
                otherNameElement.style.display = 'block'; // Show name
                otherDetailsElement.style.display = 'none'; // Hide details
            });
            this.classList.add('expand'); // Expand clicked capsule
            nameElement.style.display = 'none'; // Hide the name
            detailsElement.style.display = 'block'; // Show details
        }
    });
});
// New Project Page JavaScript
document.addEventListener('DOMContentLoaded', () => {
  // Typing effect for the heading
  const headingText = 'Portfolio';
  let i = 0;
  const headingElement = document.getElementById('portfolio-heading');

  function typeEffect() {
      if (i < headingText.length) {
          headingElement.textContent += headingText.charAt(i);
          i++;
          setTimeout(typeEffect, 150);
      }
  }
  typeEffect();

  // Slide down effect for the project boxes
  const boxes = document.querySelectorAll('.project-box');
  window.addEventListener('scroll', () => {
      boxes.forEach((box, index) => {
          const boxTop = box.getBoundingClientRect().top;
          if (boxTop < window.innerHeight) {
              box.classList.add('visible');
          }
      });
  });

  // Adding button click effect (slide down after 3 seconds)
  const buttons = document.querySelectorAll('.buttons button');
  buttons.forEach(button => {
      button.addEventListener('click', (e) => {
          setTimeout(() => {
              const buttonContainer = e.target.parentElement;
              buttonContainer.style.transform = 'translateY(100%)';
              buttonContainer.style.opacity = '0';
          }, 3000);
      });
  });

  // Redirect to GitHub when 'code' button is clicked
  const codeButtons = document.querySelectorAll('.code-btn');
  codeButtons.forEach(button => {
      button.addEventListener('click', () => {
          window.location.href = 'https://github.com/your-repository';
      });
  });
});

// Function to open the document in a new tab
function openDocument(link) {
    window.open(link, '_blank');
}
// Function to handle image slideshow
function nextImage(button) {
    // Get the parent box of the clicked button
    const box = button.parentElement;
    // Get the image container and the current active image
    const imageContainer = box.querySelector('.image-container');
    const images = imageContainer.querySelectorAll('img');
    const buttons = box.querySelectorAll('.overlay-button');

    // Find the currently active image
    let activeIndex = Array.from(images).findIndex(img => img.classList.contains('active'));

    // Hide the current image
    images[activeIndex].classList.remove('active');
    // Hide the current button
    buttons[activeIndex].style.display = 'none';

    // Calculate the next index (wrap around if necessary)
    let nextIndex = (activeIndex + 1) % images.length;

    // Show the next image
    images[nextIndex].classList.add('active');
    // Show the corresponding button for the next image with slide effect
    buttons[nextIndex].style.display = 'block';

    // Apply slide up effect to show the button
    buttons[nextIndex].classList.add('slide-up');
    setTimeout(() => {
        buttons[nextIndex].classList.remove('slide-up');
    }, 300); // Match this duration with your CSS transition duration
}
//contact page only
document.addEventListener('DOMContentLoaded', function() {
    const contactPage = document.querySelector('.contact-pages');

    if (contactPage) {
      document.getElementById('contactForm').addEventListener('submit', function(event) {
        event.preventDefault();

        // Collect form data
        const serviceID = 'service_7dm8rt7';
        const templateID = 'template_4a2yr49';

        emailjs.sendForm(serviceID, templateID, this)
          .then(() => {
            // Show success message
            const successMessage = document.getElementById('successMessage');
            successMessage.classList.add('message-active');
            successMessage.classList.add('message-blink');

            setTimeout(() => {
              successMessage.classList.remove('message-blink');
              successMessage.classList.remove('message-active');
            }, 2000);

            // Reset the form
            this.reset();
          }, (err) => {
            console.error('Failed to send email:', err);
          });
      });
    }
  });
